class NotATweetError(Exception):
    pass


class NotAvailableError(Exception):
    pass


class UnexpectedFormatError(Exception):
    pass
